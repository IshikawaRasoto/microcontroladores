#ifndef __MOTOR_H__
#define __MOTOR_H__

void ativarMotor(int graus, int velocidade, int sentido);

#endif