#ifndef __ADC_H__
#define __ADC_H__

#include <stdint.h>

void configADC(void);
uint32_t leituraADC(void);

#endif
