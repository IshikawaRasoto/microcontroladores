#ifndef __DEFINE_H__
#define __DEFINE_H__

#define CLOCK_SISTEMA 80000000

#endif
