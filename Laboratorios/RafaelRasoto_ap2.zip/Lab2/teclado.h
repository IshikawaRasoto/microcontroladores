#ifndef __TECLADO_H__
#define __TECLADO_H__

#include <stdint.h>

uint8_t teclado_ler(void);

#endif