#ifndef __LED_H__
#define __LED_H__

void ligarLeds();
void desligarLeds();

#endif